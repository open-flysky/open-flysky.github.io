2.2 : BMP renamed to IMAGES for consistency between Taranis and Horus.
You can put your model and other graphic files in this directory.
Format include bmp and png (including png with transparancy).
