PageFiles =
{
    "pids1.lua",
    "pids2.lua",
    "rates.lua",
    "pid_advanced.lua",
    "filters.lua",
    "pwm.lua",
    "rx.lua",
    "vtx.lua",
    "rescue.lua",
    "gpspids.lua",
}

MenuBox = { x= (LCD_W -250)/2, y=LCD_H/2-100, w=250, x_offset=6, h_line=35, h_offset=6 }
SaveBox = { x= (LCD_W -250)/2, y=LCD_H/2-100, w=250, x_offset=12, h=60, h_offset=12 }
NoTelem = { LCD_W/2 - 50, LCD_H - 28, "No Telemetry", TEXT_COLOR + INVERS + BLINK }
